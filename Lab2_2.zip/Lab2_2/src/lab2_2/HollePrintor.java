
package lab2_2;

 class HollePrintor {

    
    public static void main(String[] args) {
        
        String w1 = "Hello World!";
        String w2 = w1.replace("e", "*").replace("o","e").replace("*", "o");
        
        System.out.println(w2);
    }
    
}
