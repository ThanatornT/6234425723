
package lab3_2;

public class Letter {

    private final String name1;
    private final String name2;
    private String textLine = " ";
   
    public Letter(){
        name1 = " ";
        name2 = " ";
    }
    
    public Letter(String from, String to){
        name1 = from;
        name2 = to;       
    }
    
    public void addLine(String line){
        textLine = textLine + "\n" +line;
    }
    
    public String getText(){
        return "Dear "+name1+":"+"\n"+textLine+"\n\nSincerely,\n\n"+name2;
    }
  
    
}
