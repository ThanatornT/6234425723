
package lab3_2;

public class LetterTester {
    
    public static void main(String[] args){
        
        Letter myLetter = new Letter("Jade","Clarissa");
        myLetter.addLine("We must find Simon quickly.");
        myLetter.addLine("He might be in danger.");
        System.out.print(myLetter.getText());
    }
}
