package lab5_1;

public class Zeller {

    private int dayOfMonth;
    private int month;
    private int year;
    
    public Zeller(int d, int m, int y){
        dayOfMonth = d;
        if (m==1 || m==2){
            month = m+12;
            year = y-1;
        }
        else{
            month = m;
            year = y;
        }
    }
    
    public enum Day {
        SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),
        THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
        
        private final String day;
        
        Day(String day){
            this.day = day;
        }
        
        public String getDayString(){
            return day;
        }
        
  
    }
    
    public Day getDayOfWeek(){
        Day dw = null;
        int q = dayOfMonth;
        int m = month;
        int j = year/100;
        int k = year%100;
        int h = ((q)+((26*(m+1))/10)+(k)+(k/4)+(j/4)+(5*j))%7;
        switch(h){
            case 0:
                dw = Day.SATURDAY;
                break;
            case 1:
                dw = Day.SUNDAY;
                break;
            case 2:
                dw = Day.MONDAY;
                break;
            case 3:
                dw = Day.TUESDAY;
                break;
            case 4:
                dw = Day.WEDNESDAY;
                break;
            case 5:
                dw = Day.THURSDAY;
                break;
            case 6:
                dw = Day.FRIDAY;
                break;
        }
        return dw;
    }  

}

        
    
    
        
  
    

    



    
    

    
