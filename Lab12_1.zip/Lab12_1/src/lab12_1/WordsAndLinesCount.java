
package lab12_1;

import java.io.File;
import java.util.Arrays;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;

public class WordsAndLinesCount {

    
    public static void main(String[] args) throws IOException{
        File file = new File("John.txt");
        PrintWriter output = new PrintWriter(file);
        Scanner input = new Scanner(System.in);
        Scanner reader = new Scanner(file);
        int charCount = 0;
        int wordCount = 0;
        int lineCount = 0;
        String line = input.nextLine();
        while (!"quit".equals(line)){
            output.println(line);
            line = input.nextLine();
        }
        output.close();
        while (reader.hasNext()){
            lineCount++;
            String fileLine = reader.nextLine();
            charCount+=fileLine.length();
            wordCount += fileLine.split(" ").length;
        }
        
        System.out.println("Total characters : "+charCount);
        System.out.println("Total words : "+wordCount);     
        System.out.println("Total lines : "+lineCount);  
        
        reader.close();
        
    }
    
}
