package lab4_2;

public class DigitExtractor {

    private int intLeft;
    
    public DigitExtractor(int anInteger) {
        intLeft = anInteger; 
    }
    
    public int nextDigit() {
         int digit = intLeft%10;
         intLeft = intLeft/10;
         return digit;
    }
    
}
