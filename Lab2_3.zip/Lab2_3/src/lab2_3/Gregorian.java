
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Gregorian {

   
    public static void main(String[] args) {
        
        GregorianCalendar cal = new GregorianCalendar();
        cal.add(Calendar.DAY_OF_MONTH, 100);
        
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH); 
        int month = cal.get(Calendar.MONTH)+1; 
        int year = cal.get(Calendar.YEAR);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        
        System.out.println(dayOfMonth+" "+month+" "+year+" "+weekday);
        
        GregorianCalendar myBD = new GregorianCalendar(2000, Calendar.APRIL, 24);
        myBD.add(Calendar.DAY_OF_MONTH, 10000);
        
        int bdayOfMonth = myBD.get(Calendar.DAY_OF_MONTH); 
        int bmonth = myBD.get(Calendar.MONTH)+1; 
        int byear = myBD.get(Calendar.YEAR);
        int bweekday = myBD.get(Calendar.DAY_OF_WEEK);
        
        System.out.println(bdayOfMonth+" "+bmonth+" "+byear+" "+bweekday);
        
    }
    
}
