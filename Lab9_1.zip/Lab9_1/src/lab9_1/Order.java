package lab9_1;

import java.util.ArrayList;

public class Order {

    public static int cntOrder = 0; 
    private int id;
    private Customer c;
    private ArrayList<Pizza> p;
    
    public Order(Customer c){
        this.c = c;
        p = new ArrayList<Pizza>();
        cntOrder++;
        id = cntOrder;
    }
    
    public void addPizza(Pizza z){
        this.p.add(z);
    }
    
    public String getOrderDetail(){
        String pizzaList = "";
        for (Pizza pz : p){
            pizzaList += pz.toString()+"\n";
        }
        return "Order id : "+id+"\n"+c.toString()+"\n"+pizzaList+"Total pieces : "+p.size()+"\n"+"Total cost : "+calculatePayment();
        
    }
    
    public double calculatePayment(){
        int payment = 0;
        for (Pizza pz : p){
            payment+=pz.getPrice();
        }
        if (c instanceof GoldCustomer){
            return payment - ((((GoldCustomer)c).getDiscount()/100)*payment);
        } 
        else return payment;
    }
    
    
            
}
