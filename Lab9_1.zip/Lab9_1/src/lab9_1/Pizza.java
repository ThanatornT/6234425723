
package lab9_1;

public class Pizza {
    
    private String name;
    private double price;
    
    public Pizza(String name,double price){
        this.name = name;
        this.price = price;
    }
    
    @Override public String toString(){
        return getName()+" price : "+getPrice();
    }
    
    public String getName(){
        return name;
    }
    
    public double getPrice(){
        return price;
    }

}
