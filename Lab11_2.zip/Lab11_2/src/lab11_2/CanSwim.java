
package lab11_2;

public interface CanSwim {
    void swim(Terrain terrain);
}
