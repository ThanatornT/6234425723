package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.Random;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    private Button guessButton;
    private EditText numInput;
    private TextView hint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Random rand = new Random();
        final int comNum = 1+rand.nextInt(100);

        hint = (TextView) findViewById(R.id.theHint);
        numInput = (EditText) findViewById(R.id.numIn);
        guessButton = (Button) findViewById(R.id.guess);
        guessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int myNum = Integer.parseInt(numInput.getText().toString());
                if (myNum == comNum){
                    openMain3Activity();
                }
                else {
                    if (myNum > comNum){
                        hint.setText("Your guess is too high.");
                    }
                    else {
                        hint.setText("Your guess is too low.");
                    }
                }
            }
        });
    }

    public void openMain3Activity(){
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }

}
