
package lab6_3;

import java.util.Random;

public class CityGrid {

    private int xCoor;
    private int yCoor;
    private int gridSize;
    
    public CityGrid(int i){
        gridSize = i;
        xCoor = i/2;
        yCoor = i/2;
    }
    
    public void walk(){
        Random rand = new Random();
        int step = rand.nextInt(4);
        switch (step){
            case 0: 
                xCoor++;
                break;
            case 1: 
                xCoor--;
                break;
            case 2: 
                yCoor++;
                break;
            case 3: 
                yCoor--;
                break;
        }
    }
    
    public boolean isInCity(){
        return (xCoor <= gridSize && xCoor >=0 && yCoor <= gridSize && yCoor >= 0);       
    }
    
    public void reset(){
        xCoor = gridSize/2;
        yCoor = gridSize/2;
    }
    
}
