
package lab6_3;

public class CityGridTester {
    public static void main(String[] args) {
        CityGrid city = new CityGrid(10);
        double everyStepsCount = 0;
        int maxStep = 0;
        for (int i = 1; i <= 10000 ; i++){
            int stepCount = 0;
            while (city.isInCity() && stepCount < 1000){
                city.walk();
                stepCount++;
            }
            everyStepsCount = everyStepsCount + stepCount;
            if (maxStep < stepCount){
                maxStep = stepCount;
            }
            city.reset();
        }
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f",everyStepsCount/10000);
        System.out.println("\nMaximum number of steps that a person can take and is still in the city: "+maxStep);
    }
}
