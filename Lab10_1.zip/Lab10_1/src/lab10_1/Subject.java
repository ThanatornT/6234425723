
package lab10_1;

public class Subject implements Evaluation {
    
    private String subjName;
    private int[] score;
    
    public Subject(String subjName,int[] score){
        this.subjName = subjName;
        this.score = score;
    }
    
    @Override public double evaluate(){
        int totalScore = 0;
        for (int eachScore : score){
            totalScore += eachScore;
        }
        return totalScore/score.length;
    }
    
    @Override public char grade(double avgScore){
        return (avgScore >= 70) ? 'P':'F';
    }
    
    @Override public String toString(){
        return subjName;
    }
}
