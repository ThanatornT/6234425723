
package lab10_1;

public class Secretary extends Employee implements Evaluation {
    
    private int typingSpeed;
    private int[] score;
    
    public Secretary(String name,int salary,int[] score,int typingSpeed){
        super(name,salary);
        this.typingSpeed = typingSpeed;
        this.score = score;
    }
    
    @Override public double evaluate(){
        int totalScore = 0;
        for (int eachScore : score){
            totalScore += eachScore;
        }
        return totalScore;
    }
    
    @Override public char grade(double totalScore){
        if (totalScore >= 90){
            setSalary(18000);
            return 'P';
        }
        else return 'F';
    }
}
