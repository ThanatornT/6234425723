package lab4_1;

import java.util.Scanner;

public class SodaTester {
    
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter height: ");
        double h = in.nextDouble();
        
        System.out.print("Enter diameter: ");
        double d = in.nextDouble();
        
        SodaCan myCan = new SodaCan(h,d);
        
        System.out.printf("Volume: %.2f\n",myCan.getVolume());
        System.out.printf("Surface Area: %.2f",myCan.getSurfaceArea());
    }
    
    
}
