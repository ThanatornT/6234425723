package lab4_1;

import java.lang.Math;

public class SodaCan {

    private double height;
    private double diameter;
    
    public SodaCan(){
        height = 0;
        diameter = 0;
    }
   
    public SodaCan(double h,double d){
        height = h;
        diameter = d;
    }
    
    public double getVolume(){
        double volume = Math.PI*(Math.pow(diameter/2.0,2))*height;
        return volume;
    }
    
    public double getSurfaceArea(){
        double surfaceArea = (2*(Math.PI*Math.pow(diameter/2.0,2)))+(2*Math.PI*(diameter/2.0)*height);
        return surfaceArea;
    }
}
