
package lab3_3;

public class CashRegister {

    private double purchase;
    private double payment;
    private double taxpercent;
    private double totaltax;
    
    public CashRegister(double tax)
    {
       purchase = 0;
       payment = 0;
       taxpercent = tax;
       totaltax = 0;
    }
    
    public void recordPurchase(double amount)
    {
       purchase = purchase + amount;
    }
    
    public void recordTaxablePurchase(double amount)
    {
       purchase = purchase + amount + (taxpercent/100)*amount;
       totaltax = totaltax + (taxpercent/100)*amount;
    }
    
    public void enterPayment(double pay)
    {
        payment = pay;
    }
    
    public double giveTotalTax()
    {
        return totaltax;
    }
    
    public double giveChange()
    {
       double change = payment - purchase;
       purchase = 0;
       payment = 0;
       taxpercent = 0;
       return change;
    }
    
}
