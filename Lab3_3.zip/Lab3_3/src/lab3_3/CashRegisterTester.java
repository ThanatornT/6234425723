package lab3_3;

public class CashRegisterTester {
    
    public static void main(String[] args){
        
        CashRegister reg = new CashRegister(7);
        
        reg.recordPurchase(50);
        reg.recordPurchase(10);
        reg.recordTaxablePurchase(20);
        reg.enterPayment(100);
        
        System.out.println("Your change is "+reg.giveChange());
    }
}
