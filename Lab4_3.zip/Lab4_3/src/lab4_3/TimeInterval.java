package lab4_3;

public class TimeInterval {

    private int fTimeMin;
    private int sTimeMin;
    
    public TimeInterval(int startTime,int finishTime){
        fTimeMin = ((finishTime/100)*60)+(finishTime%100);
        sTimeMin = ((startTime/100)*60)+(startTime%100);
    }
    
    public int getHours(){
        int hoursDif = ((fTimeMin-sTimeMin)/60);
        return hoursDif;
    }
    
    public int getMinutes(){
        int minDif = ((fTimeMin-sTimeMin)%60);
        return minDif;
    }
}
