package lab4_3;

import java.util.Scanner;

public class TimeIntervalTester {
    
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int startTime = in.nextInt();
        System.out.print("Enter end time: ");
        int finishTime = in.nextInt();
        TimeInterval myTime = new TimeInterval(startTime,finishTime);
        System.out.print(myTime.getHours()+" hours "+myTime.getMinutes()+" minutes");
        
    }
    
}
