/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_2;
import java.io.File;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class WordCheck {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String> wordList = new ArrayList<>();
        ArrayList<String> wordInput = new ArrayList<>();
        ArrayList<String> wordNotFound = new ArrayList<>();
        try{
            File file = new File("wordlist.txt"); 
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()){
                wordList.add(reader.nextLine());
            }
            System.out.print("Enter a sentence: ");
            Scanner input = new Scanner(System.in);
            for (String word : input.nextLine().split(" ")){
                wordInput.add(word);
            }
            System.out.println("Words not contained:");
            for (String word : wordInput){
                if (!wordList.contains(word)){
                    wordNotFound.add(word);
                }
            }
            if (wordNotFound.isEmpty()){
                System.out.println("N/A");
            }
            else{
                for (String word : wordNotFound){
                    System.out.println(word);
                }
            }
            reader.close();
        }
        catch(FileNotFoundException e){
            System.out.println(e);
        }
    }
    
}
