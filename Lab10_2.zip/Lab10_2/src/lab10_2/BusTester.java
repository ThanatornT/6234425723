
package lab10_2;

import java.util.ArrayList;

public class BusTester {
    public static void main(String[] args) {
        ArrayList arr = new ArrayList();
        Hybrid a = new Hybrid(45,1200000,600,150,1);
        CNGBus b = new CNGBus(50,1000000,200,2);
        arr.add(a);
        arr.add(b);
        for (Object e : arr){
            if (e.getClass()==Hybrid.class){
                Hybrid hy = (Hybrid)e;
                System.out.println("ID : "+hy.getID()+"\nEmission Tier : "+hy.getEmissionTier()+"\nAccel : "+hy.getAccel());
            }
            else if (e.getClass()==CNGBus.class){
                CNGBus cb = (CNGBus)e;
                System.out.println("ID : "+cb.getID()+"\nEmission Tier : "+cb.getEmissionTier()+"\nAccel : "+cb.getAccel());
            }
            
        }
            
    }
}
