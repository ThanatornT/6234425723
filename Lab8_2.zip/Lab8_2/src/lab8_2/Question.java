
package lab8_2;

public class Question {
    
    private String text;
    private String answer;
    
    public Question(){
        text = "";
    }
    
    public Question(String q){
        text = q;
    }
    
    public void setText(String q){
        text = q;
    }
    
    public void setAnswer(String a){
        answer = a;
    }
    
    public String getText(){
        return text;
    }
    
    public String getAnswer(){
        return answer;
    }
    
    public boolean checkAnswer(String response){
        return (response.equals(answer));
    } 
    
    public void display(){
        System.out.println(text);
    }
    
}
