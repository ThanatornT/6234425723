
package lab8_2;

import java.util.ArrayList;

public class ChoiceQuestion extends Question {
    
    private ArrayList<String> choices;
    
    public ChoiceQuestion(String q){
        super(q);
        choices = new ArrayList<String>();
    }
    
    public void addChoice(String choice, boolean correct){
        choices.add(choice);
        if (correct == true){
            super.setAnswer(choice);
        }
    }
    
    @Override public void display(){
        System.out.println(super.getText());
        for (int i = 1;i != choices.size()+1;i++){
            System.out.println(i+" : "+choices.get(i-1));
        }
    }
    
    @Override public boolean checkAnswer(String response){
        int ans = Integer.parseInt(response);
        return (choices.get(ans-1).equals(super.getAnswer()));
    }
}
