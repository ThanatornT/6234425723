
package lab8_2;

public class NumericQuestion extends Question {
    
    public NumericQuestion(String q){
        super(q);
    }
    
    @Override public boolean checkAnswer(String response){
        double myAns = Double.parseDouble(response);
        double trueAns = Double.parseDouble(super.getAnswer());
        return (myAns - trueAns <= 0.1 && myAns - trueAns >= -0.1);
    }
}
