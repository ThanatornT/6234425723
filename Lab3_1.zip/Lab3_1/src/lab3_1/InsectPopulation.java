
package lab3_1;

public class InsectPopulation {
    
    private double num;
    
    public InsectPopulation()
    {
        num = 0;
    }
    
    public InsectPopulation(double initialNum)
    {
        num = initialNum;
    }
    
    public void breed()
    {
       num = num*2; 
    }

    public void spray()
    {
        num = num -(0.1*num);
    }
    
    public double getInsectNum()
    {
        return num;
    }
    
    
}
