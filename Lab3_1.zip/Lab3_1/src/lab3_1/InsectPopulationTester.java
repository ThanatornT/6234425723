package lab3_1;

public class InsectPopulationTester {
    
    public static void main(String[] args)
    {
        InsectPopulation insectNum = new InsectPopulation(10);
        insectNum.breed();
        insectNum.spray();
        System.out.println(insectNum.getInsectNum());
        
        insectNum.breed();
        insectNum.spray();
        System.out.println(insectNum.getInsectNum());
        
        insectNum.breed();
        insectNum.spray();
        System.out.println(insectNum.getInsectNum());
              
    }
}
