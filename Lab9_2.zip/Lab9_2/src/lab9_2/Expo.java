
package lab9_2;

import java.lang.Math;

public class Expo extends Taylor {
    
    public Expo(int k,double x){
        setIter(k);
        setValue(x);
    }
    
    @Override public void printValue(){
        System.out.println("Value from Math.exp() is "+Math.exp(getValue())+"\nApproximated value is "+getApprox());
    }
    
    @Override public double getApprox(){
        double result = 0;
        for (int i=0;i<=this.getIter();i++){
            result += (Math.pow(getValue(),i))/factorial(i);
        }
        return result;
    }
}
