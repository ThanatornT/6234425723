
package lab9_2;

import java.lang.Math;

public class Sine extends Taylor{
    
    public Sine(int k,double x){
        setIter(k);
        setValue(x);
    }
    @Override public void printValue(){
        System.out.println("Value from Math.sine() is "+Math.sin(getValue())+"\nApproximated value is "+getApprox());
    }
    
    @Override public double getApprox(){
        double result = 0;
        for (int i=0;i<=this.getIter();i++){
            result+=(Math.pow(-1,i)*Math.pow(getValue(),2*i+1))/factorial(2*i+1);          
        }
        return result;
    }
}
