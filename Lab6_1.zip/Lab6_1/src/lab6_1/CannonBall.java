
package lab6_1;

import java.lang.Math;

public class CannonBall {

    private double initV; //ความเร็วตั้งต้น
    private double simS; //ระยะทางที่คำนวณได้จากวิธี simulation
    private double simT; //เวลาที่ใช้ในวิธี simulation
    public static final double g = 9.81;
    
    public CannonBall(double v){
        initV = v;
    }
    
    public void simulatedFlight(){
        double dt = 0.01;
        double t = 0.00;
        double v = initV;
        double s = 0;
        for(int i = 1; v>=0; i++){
            double ds = v*dt;
            s = s+ds;
            v = v-(g*dt);
            t = t+dt;
            if (i%100==0){
                System.out.print("Distance on "+(i/100)+" sec: ");
                System.out.printf("%.3f\n",s);
            }    
        }
        simT = initV/g;
        s += (v/2)*v/g+0.01;
        System.out.printf("Final distance: %.3f Total time: %.1f \n", s,simT);
    }
    
    public double calculusFlight(double t){
        double s = (initV*t)-(0.5*g*Math.pow(t, 2));
        return s;
    }
    
    public double getSimulatedTime(){
        return simT;
    }
    
    public double getSimulatedDistance(){
        return simS;
    }
    
    
}
