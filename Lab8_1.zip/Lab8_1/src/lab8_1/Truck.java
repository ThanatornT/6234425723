
package lab8_1;

public class Truck extends Car{
    
    private double maxWeight;
    private double weight;
    
    public Truck(double gas,double eff,double maxWeight,double weight){
        super(gas,eff);
        this.maxWeight=maxWeight;
        this.weight = (maxWeight >= weight)? weight:maxWeight;
    }
    
    @Override public void drive(double distance){
        double extraGasUsed = 0;
        if (weight < 1){
            extraGasUsed = 0;
        }
        else if (weight >= 1 && weight <= 10){
            extraGasUsed = 0.1*(distance/super.getEfficiency());
        }
        else if (weight > 10 && weight <= 20){
            extraGasUsed = 0.2*(distance/super.getEfficiency());
        }
        else if (weight > 20){
            extraGasUsed = 0.3*(distance/super.getEfficiency());
        }
        
        double totalGasUsed = (distance/super.getEfficiency())+extraGasUsed;
        
        if (totalGasUsed > super.getGas()){
            System.out.println("You cannot drive too far, please add gas");
        }
        else{
            super.setGas(getGas()-totalGasUsed);
        }
    }
    
}
