
package lab8_1;

public class Car {

    private double gas;
    private double eff;
        
    public Car(double gas,double eff){
        this.gas = gas;
        this.eff = eff;
    }
    
    public void drive(double distance){
        if (distance/eff > gas){
            System.out.println("You cannot drive too far, please add gas");
        }
        else{
            gas -= (distance/eff);
        }
    }
    
    public void setGas(double amount){
        gas = amount;
    }
    
    public double getGas(){
        return gas;
    }
    
    public double getEfficiency(){
        return eff;
    }
    
    public void addGas(double amount){
        gas+=amount;
    }
}
