package lab7_2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MagicSquare {
    private String square;
    private int[][] demo;
    
    public MagicSquare(int n){
        square = "";
        int i = n-1;
        int j = (n-1)/2;        
        demo = new int[n][n];
        for(int k = 1;k <= n*n;k++){
            if(j>n-1&i>n-1){
                i -= 2;
                j -= 1;}
            else if (i>n-1&j>0){                    
                i = 0;}
            else if(j>n-1&i>0){
                j = 0;}
            else if(demo[i][j] != 0){
                i -= 2;
                j -= 1;}             
            demo[i][j] = k;            
            i++;
            j++;               
        }        
    }
    
    @Override
    public String toString(){        
        for (int[] demo1 : demo) {
            for (int t = 0; t < demo.length; t++) {
                square += demo1[t] + "\t";
            }
            square += "\n\n";
        }
        return square;
    } 
}
   