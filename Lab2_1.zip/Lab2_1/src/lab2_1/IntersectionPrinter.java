
package lab2_1;

import java.awt.Rectangle;
import java.util.Random;

public class IntersectionPrinter {

    
    public static void main(String[] args) {
        
        Random generator = new Random();
        int x1=generator.nextInt(50);
        int y1=generator.nextInt(50);
        int w1=generator.nextInt(50);
        int h1=generator.nextInt(50);
        int x2=generator.nextInt(50);
        int y2=generator.nextInt(50);
        int w2=generator.nextInt(50);
        int h2=generator.nextInt(50);
        
        Rectangle r1 = new Rectangle(x1+1,y1+1,w1+1,h1+1);
        Rectangle r2 = new Rectangle(x2+1,y2+1,w2+1,h2+1);
        
        Rectangle r3 = r1.intersection(r2);
        
        System.out.println(r1);
        System.out.println(r2);
        System.out.println("Is the intersected rectangle empty?:"+r3.isEmpty());
    }
    
}
