/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.IOException;
/**
 *
 * @author User
 */
public class FileMatch {
    public static void main(String[] args){
        ArrayList<AccountRecord> accts = new ArrayList<>();
        ArrayList<TransactionRecord> transact = new ArrayList<>();
        RandomAccessFile newMaster = null;
        File master = new File("master.txt");
        File trans = new File("trans.txt");
        int totalAcct = 0;
        double totalBal = 0;
        int noTransAcct = 0;
        try(Scanner mRead = new Scanner(master);
            Scanner tRead = new Scanner(trans);){
            newMaster = new RandomAccessFile("newMaster.dat","rw");
            while (mRead.hasNext()){
                accts.add(new AccountRecord(mRead.nextInt(),mRead.next()+" "+mRead.next(),mRead.nextDouble()));
            }
            while (tRead.hasNext()){
                transact.add(new TransactionRecord(tRead.nextInt(),tRead.nextDouble()));
            }
            for (AccountRecord a : accts){
                for (TransactionRecord t : transact){
                    if (t.getAccountNum()==a.getAcctNo()){
                        a.combine(t);
                    }
                }
            }
            for (AccountRecord a : accts){
                newMaster.writeInt(a.getAcctNo());
                newMaster.writeChar(',');
                String newName = a.getName();
                if (a.getName().length()<30){                   
                    while(newName.length() < 30){
                        newName+=" ";
                    }
                }
                newMaster.writeChars(newName);
                newMaster.writeChar(',');
                newMaster.writeDouble(a.getBalance());
                newMaster.writeChar(',');
                newMaster.writeInt(a.getTransCnt());
                newMaster.writeChar('\n');
            }  
            for (int i = 84;i<=336;i=i+84){
                totalAcct++;
            }            
            System.out.println("Total Account Record : "+totalAcct);
            for (int i = 68;i<=336;i=i+84){
                newMaster.seek(i);
                totalBal+=newMaster.readDouble();
            }
            System.out.println("Total balance : "+totalBal);
            for (int i = 78;i<=336;i=i+84){
                newMaster.seek(i);
                if (newMaster.readInt()==0){
                    noTransAcct++;
                }
            }
            System.out.println("No transaction : "+noTransAcct+" account");
        }
        catch(FileNotFoundException e){
            System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
}
