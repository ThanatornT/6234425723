
package lab12_3;

public class TransactionRecord {
    private int acctNo;
    private double transAm;
    public TransactionRecord(int accountNo,double transAm){
        this.acctNo = accountNo;
        this.transAm = transAm;
    }
    public int getAccountNum(){
        return acctNo;
    }
    public double getTransAm(){
        return transAm;
    }
    public void setAccountNum(){
         this.acctNo = acctNo;
    }
    public void setTransAm(){
        this.transAm = transAm;
    }
}
