
package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue{
    private ArrayList<String> songList;
    public MusicBox(){
        songList = new ArrayList<String>();
    }
    @Override public void enqueue(Object song){
        String songName = (String) song;
        songList.add(songName);
        System.out.println(songName+" is added in queue");
    }
    @Override public void dequeue(){
        System.out.println("Now playing "+songList.get(0));       
        songList.remove(0);
    }
}
