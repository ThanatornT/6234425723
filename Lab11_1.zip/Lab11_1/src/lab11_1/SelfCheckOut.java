
package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue{
    private ArrayList<Product> productList;
    private double price;
    public SelfCheckOut(){
        productList = new ArrayList<Product>();
    }
    @Override public void enqueue(Object product){
        Product productAdded = (Product)product;
        productList.add(productAdded);
        System.out.println(productAdded.getName()+" is added to the queue");
    }
    @Override public void dequeue(){
        price+=productList.get(0).getPrice();
        productList.remove(0);
    }   
    public double getAmount(){
        return price;
    }
    
}
