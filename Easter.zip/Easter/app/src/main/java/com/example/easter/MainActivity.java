package com.example.easter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.text.DateFormatSymbols;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText yrText;
    private Button easterButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findEaster();
    }

    public void findEaster(){

        yrText =  (TextInputEditText) findViewById(R.id.textInputLayout);
        easterButton = (Button) findViewById(R.id.button);

        easterButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){

                int y = Integer.parseInt(yrText.getText().toString());
                int a = y%19;
                int b = y/100;
                int c = y%100;
                int d = b/4;
                int e = b%4;
                int g = ((8*b)+13)/25;
                int h = ((19*a)+b-d-g+15)%30;
                int j = c/4;
                int k = c%4;
                int m = (a+(11*h))/319;
                int r = ((2*e)+(2*j)-k-h+m+32)%7;
                int n = (h-m+r+90)/25;
                int p = (h-m+r+n+19)%32;

                String nMonth = new DateFormatSymbols().getMonths()[n-1];

                Toast.makeText(getApplicationContext(),nMonth+" "+p, Toast.LENGTH_LONG).show();

            }
        });

    }

}
