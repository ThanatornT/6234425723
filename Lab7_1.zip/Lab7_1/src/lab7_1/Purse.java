package lab7_1;

import java.util.ArrayList;

public class Purse {
    
    private ArrayList<String> purse;
    private int nickel;
    private int dime;
    private int quarter;
    
    public Purse(){
        purse = new ArrayList<>();
        nickel = 0;
        dime = 0;
        quarter = 0;
    }
    
    public void addCoin(String coinName){
        purse.add(coinName);
    }
    
    public String toString(){
        String out = "";
        if (purse.isEmpty()){
            return "Purse[]";
        }       
        else {
            for (int i = 0;i < purse.size();i++){
                out = out+purse.get(i)+",";
            }
            out = out.substring(0,out.length()-1);
            return "Purse["+out+"]";
        }
    }
    
    public ArrayList<String> reverse(){
        ArrayList<String> revPurse = new ArrayList<>();
        if (purse.isEmpty()){
            return purse;
        }
        else {
            for (int i = purse.size()-1; i >= 0; --i) {
                revPurse.add(purse.get(i));
            }
            return revPurse;
        }
    }
    
    public void transfer(Purse other){
        for (int i = 0;i < this.purse.size();i++){
            other.purse.add(this.purse.get(i));
        }
        this.purse.clear();
    }
        
    public boolean sameContents(Purse other){     
        boolean check = true;
        int size;
        if (this.purse.size() > other.purse.size()){
            size = other.purse.size();
        }
        else{
            size = this.purse.size();
        }
        for (int i=0;i < size;i++){
            check = this.purse.get(i).equals(other.purse.get(i));
        }
        return check;
    }
    
    public boolean sameCoins(Purse other){
        int asize = this.purse.size();
        int bsize = other.purse.size();
        for (int i = 0;i < asize;i++){
            switch (this.purse.get(i)){
                case "Nickel":
                    this.nickel++;
                case "Dime":
                    this.dime++;
                case "Quarter":
                    this.quarter++;                
            }
        }
        for (int j = 0;j < bsize;j++){
            switch (other.purse.get(j)){
                case "Nickel":
                    other.nickel++;
                case "Dime":
                    other.dime++;
                case "Quarter":
                    other.quarter++;              
            }
        }
        boolean check = this.nickel == other.nickel && this.dime == other.dime && this.quarter == other.quarter;
        return check;
    }

    
}
