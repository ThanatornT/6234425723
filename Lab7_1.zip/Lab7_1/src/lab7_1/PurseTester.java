package lab7_1;

public class PurseTester {
    
    public static void main(String[] args) {
        Purse a = new Purse();
        Purse b = new Purse();

        a.addCoin("Nickel");
        a.addCoin("Quarter");
        a.addCoin("Dime");
        b.addCoin("Nickel");
        b.addCoin("Dime");
        b.addCoin("Quarter");
        a.transfer(b);
        System.out.print(a.toString());
    }
}
