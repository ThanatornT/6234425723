package lab6_2;

import java.util.Scanner;
import java.util.Random;

public class Game {
    
    private int myScore;
    private int comScore;

    public Game(){
        myScore=0;
        comScore=0;
    }
    
    private enum Move{
        ROCK,PAPER,SCISSOR;
        
        public int getWinner(Move otherMove){
            if (this == otherMove){
                return 0;
            }
            
            else{
                switch (this){
                    case ROCK:
                        if (otherMove == SCISSOR){
                            return 1;
                        }
                    case PAPER:
                        if (otherMove == ROCK){
                            return 1;
                        }
                    case SCISSOR:
                        if (otherMove == PAPER){
                            return 1;
                        }
                    default:
                        return -1;
                }
            }
        }
    }
    
    public void play(){
        
        while (myScore - comScore != 2 && comScore - myScore != 2){
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            Scanner rpsInput = new Scanner(System.in);
            
            String myInput = rpsInput.nextLine();
            if(!myInput.equals("0") && !myInput.equals("1") && !myInput.equals("2")){
                continue;
            }
            Move myMove = Move.values()[Integer.parseInt(myInput)];
            System.out.println("You enter: "+myMove);
            
            Random rand = new Random();
            Move comMove = Move.values()[rand.nextInt(3)];
            System.out.println("Computer: "+comMove);
            
            switch (myMove.getWinner(comMove)){
                case 1:
                    myScore++;
                    System.out.println("You win!");
                    break;
                case -1:
                    comScore++;
                    System.out.println("You lose!");
                    break;
                case 0:
                    System.out.println("It's a tie.");
                    break;
            }
        }
        
        System.out.println("----------------------------------------");
        if (myScore > comScore){
            System.out.println("Congrats! You win.");
        }
        else {
            System.out.println("Too bad! You lose.");
        }
        System.out.print("User Score: "+myScore+"\nComputer score: "+comScore);
    }
    
}
